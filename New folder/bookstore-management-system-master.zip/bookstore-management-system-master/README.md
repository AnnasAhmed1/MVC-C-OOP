# Bookstore Management System
* A data storage web service using ASP.NET web service
* A bookstore application using ASP.NET MVC and invoking the data storage web service
