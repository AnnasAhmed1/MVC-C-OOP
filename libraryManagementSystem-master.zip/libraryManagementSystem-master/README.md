## Kütüphane Yönetim Sistemi
Veritabanı Yönetim Sistemleri dersi için ödev olarak geliştirilmiş bir projedir.

C# ile yazılmıştır. 

Veritabanı için MySql tercih edilmiştir.

Projenin detaylı raporuna aşağıdaki bağlantıdan ulaşabilirsiniz.

[Rapor.pdf](https://github.com/ErenSaskin/libraryManagementSystem/blob/1d57543e48a3aa99ed2ad6760ad94dcfc64775ab/Rapor.pdf)