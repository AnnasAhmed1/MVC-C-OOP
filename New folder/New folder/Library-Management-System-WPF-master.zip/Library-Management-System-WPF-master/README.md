# Library-Management-System-WPF
This is a C # WPF based library management system that can be accessed throughout the campus. This system can be used to search for books, reserve books, and issue/return books from the library. This is an integrated system that contains both the user component and the librarian component.
Technologies are used : C#, WPF, SQL Server, Three tier architecture
