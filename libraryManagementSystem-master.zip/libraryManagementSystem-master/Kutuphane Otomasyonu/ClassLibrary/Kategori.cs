﻿namespace ClassLibrary
{
    public class Kategori
    {
        public int kategoriID { get; set; }
        public string ad { get; set; }
    }
}
