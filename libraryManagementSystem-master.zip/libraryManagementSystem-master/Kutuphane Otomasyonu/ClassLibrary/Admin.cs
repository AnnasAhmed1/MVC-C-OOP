﻿namespace ClassLibrary
{
    public class Admin
    {
        public string adminID { get; set; }
        public string ad { get; set; }
        public string soyad { get; set; }
        public string eMail { get; set; }
        public string sifre { get; set; }
        public string telefon { get; set; }
        public string adres { get; set; }

    }
}
