﻿namespace Kutuphane2
{
    partial class FormEmanetIslemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.yetkiliIDTxt = new System.Windows.Forms.TextBox();
            this.islemAraTxt = new System.Windows.Forms.TextBox();
            this.kitapAraTxt = new System.Windows.Forms.TextBox();
            this.uyeIDTxt = new System.Windows.Forms.TextBox();
            this.kitapIDTxt = new System.Windows.Forms.TextBox();
            this.durumTxt = new System.Windows.Forms.TextBox();
            this.uyariLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.alBtn = new System.Windows.Forms.Button();
            this.verTemizleBtn = new System.Windows.Forms.Button();
            this.islemAraBtn = new System.Windows.Forms.Button();
            this.verBtn = new System.Windows.Forms.Button();
            this.kitapAraBtn = new System.Windows.Forms.Button();
            this.uyeAraTxt = new System.Windows.Forms.TextBox();
            this.uyeAraBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(341, 553);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(99, 42);
            this.button10.TabIndex = 113;
            this.button10.Text = "Düzenle";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(466, 553);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(99, 42);
            this.button11.TabIndex = 112;
            this.button11.Text = "Sil";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.dataGridView3);
            this.panel1.Controls.Add(this.dataGridView2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.yetkiliIDTxt);
            this.panel1.Controls.Add(this.islemAraTxt);
            this.panel1.Controls.Add(this.kitapAraTxt);
            this.panel1.Controls.Add(this.uyeIDTxt);
            this.panel1.Controls.Add(this.kitapIDTxt);
            this.panel1.Controls.Add(this.durumTxt);
            this.panel1.Controls.Add(this.uyariLbl);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.alBtn);
            this.panel1.Controls.Add(this.verTemizleBtn);
            this.panel1.Controls.Add(this.islemAraBtn);
            this.panel1.Controls.Add(this.verBtn);
            this.panel1.Controls.Add(this.kitapAraBtn);
            this.panel1.Controls.Add(this.uyeAraTxt);
            this.panel1.Controls.Add(this.uyeAraBtn);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(880, 660);
            this.panel1.TabIndex = 114;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical;
            this.dataGridView3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dataGridView3.ColumnHeadersHeight = 25;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridView3.EnableHeadersVisualStyles = false;
            this.dataGridView3.Location = new System.Drawing.Point(30, 442);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.RowHeadersWidth = 20;
            this.dataGridView3.RowTemplate.Height = 40;
            this.dataGridView3.Size = new System.Drawing.Size(838, 203);
            this.dataGridView3.TabIndex = 149;
            this.dataGridView3.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridView2.ColumnHeadersHeight = 25;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.Location = new System.Drawing.Point(271, 230);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 20;
            this.dataGridView2.RowTemplate.Height = 40;
            this.dataGridView2.Size = new System.Drawing.Size(597, 131);
            this.dataGridView2.TabIndex = 149;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridView1.ColumnHeadersHeight = 25;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(271, 45);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(52)))), ((int)(((byte)(52)))));
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 20;
            this.dataGridView1.RowTemplate.Height = 40;
            this.dataGridView1.Size = new System.Drawing.Size(597, 128);
            this.dataGridView1.TabIndex = 149;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // yetkiliIDTxt
            // 
            this.yetkiliIDTxt.Enabled = false;
            this.yetkiliIDTxt.Location = new System.Drawing.Point(111, 19);
            this.yetkiliIDTxt.Multiline = true;
            this.yetkiliIDTxt.Name = "yetkiliIDTxt";
            this.yetkiliIDTxt.Size = new System.Drawing.Size(137, 20);
            this.yetkiliIDTxt.TabIndex = 129;
            // 
            // islemAraTxt
            // 
            this.islemAraTxt.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.islemAraTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(173)))), ((int)(((byte)(173)))));
            this.islemAraTxt.Location = new System.Drawing.Point(271, 410);
            this.islemAraTxt.Multiline = true;
            this.islemAraTxt.Name = "islemAraTxt";
            this.islemAraTxt.Size = new System.Drawing.Size(508, 20);
            this.islemAraTxt.TabIndex = 137;
            this.islemAraTxt.Text = "İşlem ID, Uye Adı, Kitap Adı, ISBN";
            this.islemAraTxt.Enter += new System.EventHandler(this.islemAraTxt_Enter);
            this.islemAraTxt.Leave += new System.EventHandler(this.islemAraTxt_Leave);
            // 
            // kitapAraTxt
            // 
            this.kitapAraTxt.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kitapAraTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(173)))), ((int)(((byte)(173)))));
            this.kitapAraTxt.Location = new System.Drawing.Point(271, 199);
            this.kitapAraTxt.Multiline = true;
            this.kitapAraTxt.Name = "kitapAraTxt";
            this.kitapAraTxt.Size = new System.Drawing.Size(508, 20);
            this.kitapAraTxt.TabIndex = 137;
            this.kitapAraTxt.Text = "Kitap Adı, Yazar Adı, ISBN, Kategori Adı";
            this.kitapAraTxt.Enter += new System.EventHandler(this.kitapAraTxt_Enter);
            this.kitapAraTxt.Leave += new System.EventHandler(this.kitapAraTxt_Leave);
            // 
            // uyeIDTxt
            // 
            this.uyeIDTxt.Enabled = false;
            this.uyeIDTxt.Location = new System.Drawing.Point(111, 50);
            this.uyeIDTxt.Multiline = true;
            this.uyeIDTxt.Name = "uyeIDTxt";
            this.uyeIDTxt.Size = new System.Drawing.Size(103, 20);
            this.uyeIDTxt.TabIndex = 130;
            // 
            // kitapIDTxt
            // 
            this.kitapIDTxt.Enabled = false;
            this.kitapIDTxt.Location = new System.Drawing.Point(111, 81);
            this.kitapIDTxt.Multiline = true;
            this.kitapIDTxt.Name = "kitapIDTxt";
            this.kitapIDTxt.Size = new System.Drawing.Size(137, 20);
            this.kitapIDTxt.TabIndex = 131;
            // 
            // durumTxt
            // 
            this.durumTxt.Enabled = false;
            this.durumTxt.Location = new System.Drawing.Point(230, 50);
            this.durumTxt.Multiline = true;
            this.durumTxt.Name = "durumTxt";
            this.durumTxt.Size = new System.Drawing.Size(18, 20);
            this.durumTxt.TabIndex = 132;
            // 
            // uyariLbl
            // 
            this.uyariLbl.AutoSize = true;
            this.uyariLbl.ForeColor = System.Drawing.Color.Red;
            this.uyariLbl.Location = new System.Drawing.Point(44, 230);
            this.uyariLbl.Name = "uyariLbl";
            this.uyariLbl.Size = new System.Drawing.Size(29, 13);
            this.uyariLbl.TabIndex = 147;
            this.uyariLbl.Text = "uyarı";
            this.uyariLbl.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 147;
            this.label1.Text = "Teslim Tarihi :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 147;
            this.label3.Text = "İşlem Tarihi :";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Enabled = false;
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dateTimePicker2.Location = new System.Drawing.Point(111, 142);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(137, 20);
            this.dateTimePicker2.TabIndex = 146;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(46, 23);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 13);
            this.label24.TabIndex = 140;
            this.label24.Text = "Yetkili ID :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dateTimePicker1.Location = new System.Drawing.Point(111, 114);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(137, 20);
            this.dateTimePicker1.TabIndex = 146;
            this.dateTimePicker1.Value = new System.DateTime(2020, 5, 19, 5, 34, 0, 0);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(55, 54);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(46, 13);
            this.label23.TabIndex = 141;
            this.label23.Text = "Uye ID :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(50, 85);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 13);
            this.label22.TabIndex = 142;
            this.label22.Text = "Kitap ID :";
            // 
            // alBtn
            // 
            this.alBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.alBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(202)))));
            this.alBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(202)))));
            this.alBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.alBtn.Location = new System.Drawing.Point(47, 401);
            this.alBtn.Name = "alBtn";
            this.alBtn.Size = new System.Drawing.Size(208, 35);
            this.alBtn.TabIndex = 133;
            this.alBtn.Text = "Teslim Al";
            this.alBtn.UseVisualStyleBackColor = true;
            this.alBtn.Click += new System.EventHandler(this.alBtn_Click);
            // 
            // verTemizleBtn
            // 
            this.verTemizleBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.verTemizleBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(83)))), ((int)(((byte)(79)))));
            this.verTemizleBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(83)))), ((int)(((byte)(79)))));
            this.verTemizleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.verTemizleBtn.Location = new System.Drawing.Point(40, 179);
            this.verTemizleBtn.Name = "verTemizleBtn";
            this.verTemizleBtn.Size = new System.Drawing.Size(59, 42);
            this.verTemizleBtn.TabIndex = 133;
            this.verTemizleBtn.Text = "Temizle";
            this.verTemizleBtn.UseVisualStyleBackColor = true;
            this.verTemizleBtn.Click += new System.EventHandler(this.verTemizleBtn_Click);
            // 
            // islemAraBtn
            // 
            this.islemAraBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.islemAraBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.islemAraBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.islemAraBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.islemAraBtn.Location = new System.Drawing.Point(785, 405);
            this.islemAraBtn.Name = "islemAraBtn";
            this.islemAraBtn.Size = new System.Drawing.Size(83, 27);
            this.islemAraBtn.TabIndex = 138;
            this.islemAraBtn.Text = "Ara";
            this.islemAraBtn.UseVisualStyleBackColor = true;
            this.islemAraBtn.Click += new System.EventHandler(this.islemAraBtn_Click);
            // 
            // verBtn
            // 
            this.verBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.verBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(92)))));
            this.verBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(184)))), ((int)(((byte)(92)))));
            this.verBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.verBtn.Location = new System.Drawing.Point(111, 179);
            this.verBtn.Name = "verBtn";
            this.verBtn.Size = new System.Drawing.Size(137, 42);
            this.verBtn.TabIndex = 133;
            this.verBtn.Text = "Kitap Ver";
            this.verBtn.UseVisualStyleBackColor = true;
            this.verBtn.Click += new System.EventHandler(this.verBtn_Click);
            // 
            // kitapAraBtn
            // 
            this.kitapAraBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.kitapAraBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.kitapAraBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.kitapAraBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kitapAraBtn.Location = new System.Drawing.Point(785, 194);
            this.kitapAraBtn.Name = "kitapAraBtn";
            this.kitapAraBtn.Size = new System.Drawing.Size(83, 27);
            this.kitapAraBtn.TabIndex = 138;
            this.kitapAraBtn.Text = "Ara";
            this.kitapAraBtn.UseVisualStyleBackColor = true;
            this.kitapAraBtn.Click += new System.EventHandler(this.kitapAraBtn_Click);
            // 
            // uyeAraTxt
            // 
            this.uyeAraTxt.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.uyeAraTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(173)))), ((int)(((byte)(173)))));
            this.uyeAraTxt.Location = new System.Drawing.Point(271, 16);
            this.uyeAraTxt.Multiline = true;
            this.uyeAraTxt.Name = "uyeAraTxt";
            this.uyeAraTxt.Size = new System.Drawing.Size(508, 20);
            this.uyeAraTxt.TabIndex = 134;
            this.uyeAraTxt.Text = "Ad, Soyad, E-Mail";
            this.uyeAraTxt.Enter += new System.EventHandler(this.uyeAraTxt_Enter);
            this.uyeAraTxt.Leave += new System.EventHandler(this.uyeAraTxt_Leave);
            // 
            // uyeAraBtn
            // 
            this.uyeAraBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uyeAraBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.uyeAraBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.uyeAraBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.uyeAraBtn.Location = new System.Drawing.Point(785, 12);
            this.uyeAraBtn.Name = "uyeAraBtn";
            this.uyeAraBtn.Size = new System.Drawing.Size(83, 27);
            this.uyeAraBtn.TabIndex = 135;
            this.uyeAraBtn.Text = "Ara";
            this.uyeAraBtn.UseVisualStyleBackColor = true;
            this.uyeAraBtn.Click += new System.EventHandler(this.uyeAraBtn_Click);
            // 
            // FormEmanetIslemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(880, 660);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormEmanetIslemleri";
            this.Text = "FormEmanetIslemleri";
            this.Load += new System.EventHandler(this.FormEmanetIslemleri_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox yetkiliIDTxt;
        private System.Windows.Forms.TextBox kitapAraTxt;
        private System.Windows.Forms.TextBox uyeIDTxt;
        private System.Windows.Forms.TextBox kitapIDTxt;
        private System.Windows.Forms.TextBox durumTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button verBtn;
        private System.Windows.Forms.Button kitapAraBtn;
        private System.Windows.Forms.TextBox uyeAraTxt;
        private System.Windows.Forms.Button uyeAraBtn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button alBtn;
        private System.Windows.Forms.Button verTemizleBtn;
        private System.Windows.Forms.TextBox islemAraTxt;
        private System.Windows.Forms.Button islemAraBtn;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label uyariLbl;
    }
}