Library Management System ==> WPF
==> The project solution is inside the LibraryManagementSystem folder. 