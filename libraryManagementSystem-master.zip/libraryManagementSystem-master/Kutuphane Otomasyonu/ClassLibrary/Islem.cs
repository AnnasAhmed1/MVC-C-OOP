﻿namespace ClassLibrary
{
    public class Islem
    {
        public int islemID { get; set; }
        public int uyeID { get; set; }
        public int kitapID { get; set; }
        public string islemTarihi { get; set; }
        public string iadeTarihi { get; set; }
        public bool islemDurumu { get; set; }

        public int adminID { get; set; }
        public string emanetDurumu { get; set; }

    }
}
