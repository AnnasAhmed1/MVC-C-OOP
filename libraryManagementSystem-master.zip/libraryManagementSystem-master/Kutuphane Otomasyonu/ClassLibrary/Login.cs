﻿namespace ClassLibrary
{
    public class Login
    {
        public string girisYapID { get; set; }
        public string eMail { get; set; }
        public string sifre { get; set; }

        public string adSoyad { get; set; }
    }
}